import { Routes } from '@angular/router' 
import {
  EventsListComponent,
  CreateEventComponent,
  EventsListResolver,
  EventsDetailsComponent,
  EventsRouteActivator,
  CreateSessionComponent,
  EventsResolver
} from './events/index'
import { Error404Component } from './errors/404-component'

export const appRoutes:Routes = [
  { path : 'events/new', component:CreateEventComponent, canDeactivate: ['canDeactivateCreateEvent']} ,
  //{ path : 'events/new', component:CreateEventComponent} ,
  { path : 'events', component:EventsListComponent, resolve:{events:EventsListResolver}},
 // { path : 'events/:id', component:EventsDetailsComponent , canActivate: [EventsRouteActivator]} ,
  { path : 'events/:id', component:EventsDetailsComponent , resolve:{event:EventsResolver}} ,
  { path : '404', component:Error404Component} ,
  { path : 'events/session/new', component:CreateSessionComponent} ,
  { path : '', redirectTo:'/events', pathMatch:'full'} ,
  { path : 'user', loadChildren:'app/user/user.module#UserModule'}
]