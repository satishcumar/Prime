"use strict";
var core_1 = require('@angular/core');
exports.TOASTR_TOKEN = new core_1.OpaqueToken('toastr');
//# sourceMappingURL=toastr.service.js.map