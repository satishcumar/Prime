import {NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {RouterModule}  from '@angular/router'
import {FormsModule, ReactiveFormsModule}  from '@angular/forms'
import {HttpModule}  from '@angular/http'
import {
  EventsListComponent,
  EventsThumbNailComponent,
  EventService,
  CreateEventComponent,
  EventsListResolver,
  EventsDetailsComponent,
  CreateSessionComponent,
  UpvoteComponent,
  SessionListComponent,
  EventsRouteActivator,
  EventsResolver,
  DurationPipe,
  VoterService,
  LocationValidator,
} from './events/index'
import { TOASTR_TOKEN , 
	Toastr,
	JQ_TOKEN,
	CollapsibleWellComponent,
	SimpleModalComponent,
	ModalTriggerDirective
	} from './common/index'
import {EventsAppComponent} from './events-apps-component'
import {NavbarComponent} from './nav/navbar-component'
import {Error404Component} from './errors/404-component'
import {AuthService} from './user/auth.service'

declare let jQuery : Object
//declare let toastr : Toastr
import {appRoutes} from './routes'
@NgModule({
	imports: [
		BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
		RouterModule.forRoot(appRoutes)
		],
	declarations: [
				EventsAppComponent, 
				EventsListComponent,
				EventsThumbNailComponent,
				EventsDetailsComponent,
				NavbarComponent,
				CreateEventComponent,
        CreateSessionComponent,
        UpvoteComponent,
        SessionListComponent,
				Error404Component,
        CollapsibleWellComponent,
        SimpleModalComponent,
        ModalTriggerDirective,
        LocationValidator,
        DurationPipe			
				],
	providers : [
				EventService,
				VoterService,
				{ provide: JQ_TOKEN, useValue: jQuery }, 
        //{ provide: TOASTR_TOKEN, useValue: toastr }, 
				EventsRouteActivator,
				EventsListResolver,
				EventsResolver,
        AuthService,
				{
				provide: 'canDeactivateCreateEvent',
				useValue: checkDirtyState
				}				
				],
	bootstrap: [EventsAppComponent]
})
export class AppModule {}
function checkDirtyState(component:CreateEventComponent){
    if(component.isDirty)
    	 return window.confirm('Do you really want this event ?')
    return false
}

