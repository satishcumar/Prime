// <button class="btn btn-primary" (click)="handleClickMe()"> Click me !! </button>
import { Component ,Input , Output, EventEmitter } from '@angular/core'
import {IEvent} from './shared/index'
@Component({
     selector: 'events-thumbnail',
     template: `
        <div [routerLink]="['/events',event.id]" class="well hoverwell thumbnail">
        <h2>{{event?.name | uppercase}}</h2>
          <div> Date : {{event?.date | date: 'shortDate' }} </div>
          <div [ngStyle] = "getStartTimeStyle()" [ngSwitch]= "event?.time"> Time : {{event?.time}} 
            <span *ngSwitchCase="'8:00 am'"> (Early Start)</span>
            <span *ngSwitchCase="'10:00 am'"> (Late Start)</span>
            <span *ngSwitchDefault> (Normal Start)</span>
          </div>
          <div> Price : {{event?.price | currency:'USD':true}} </div>
          <div *ngIf="event?.location">
            <span> Location : {{event?.location?.address}}, </span>
            <span> &nbsp; </span>
            <span class="pad-left"> {{event?.location?.city}} , &nbsp;  {{event?.location?.country}}</span> 
          </div>
          <div *ngIf="event?.onlineUrl">
              Online URL : {{event?.onlineUrl}}
          </div>          
      </div>`,
      styles : [`
          .green {color:#003300 !important;}
          .bold {font-weight: bold;}
          .red {color:red !important;}
          .yellow {color:yellow !important;}
          .thumbnail {min-height: 210px;} 
          .pad-left {margin-left: 10px; }
          .well div {color:#bbb ; }
        `]
     })
 export class EventsThumbNailComponent{
   @Input() event :IEvent  
   @Output() eventClick = new EventEmitter()
   someProperty = "Some Value"
    handleClickMe(){
      this.eventClick.emit(this.event.name)
      console.log("Clicked !!")
    }
  
    logSatish(){
      console.log("Satish !!!")
    }
     getStartTimeCls(){
        const isEarlyStart = this.event && this.event.time === '8:00 am'
        return {green :isEarlyStart, bold :isEarlyStart}
     }
        
    getStartTimeClass(){
        if(this.event && this.event.time === '10:00 am')
            return 'red bold'
         return ''
   }
    getStartTimeArrayClass(){
        if(this.event && this.event.time === '9:00 am')
            return ['yellow bold']
         return []
   }
    getStartTimeStyle():any{
        if(this.event && this.event.time === '8:00 am')
            return {color:'#003300', 'font-weight':'bold'}
        return {}
    }
 }