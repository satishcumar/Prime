package com.random.data;

public class QueueData {
	private boolean isProcessed;
	
	private int iData;
	
	private boolean bResult;

	public boolean isProcessed() {
		return isProcessed;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	public int getiData() {
		return iData;
	}

	public void setiData(int iData) {
		this.iData = iData;
	}

	public boolean isbResult() {
		return bResult;
	}

	public void setbResult(boolean bResult) {
		this.bResult = bResult;
	}
	

}
