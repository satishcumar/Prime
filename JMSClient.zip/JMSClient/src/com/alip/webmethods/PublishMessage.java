package com.alip.webmethods;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.webmethods.jms.WmConnectionFactory;


public class PublishMessage {
	static Logger logger = Logger.getLogger(PublishMessage.class);

	public static void main(String[] args)  {
		String mqEnv = System.getProperty("mqEnv");
		if("WebMethods".equals(mqEnv)){
			executeWebMethods();
		}else if("ActiveMQ".equals(mqEnv)){
			executeActiveMQ();
		}else{
			logger.error("Invalid MQ Environment +"+mqEnv+"+. Please check the jvm argument mqEnv");
		}
    	System.exit(1);
        
	}
	private static void executeActiveMQ(){
		Connection connection = null;
		boolean readMessage = false;
		try{
			if("Y".equals(System.getProperty("readMessageFromResponse"))){
				readMessage = true;
			}
			ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(System.getProperty("URL"));
			 connection = connectionFactory.createConnection();
	            connection.start();
	            logger.info("Connection Created" + connection.toString());
	            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	            Destination adminQueue = session.createQueue(System.getProperty("RequestQueue"));
	            MessageProducer producer = session.createProducer(adminQueue);
	            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
	            TextMessage msg = session.createTextMessage();  //Create Message
				String fileName = System.getProperty("FileName");
				String message = readFile(fileName,Charset.defaultCharset());
				msg.setText(message);
				msg.setStringProperty("siteid", System.getProperty("SiteId"));
				String correlationId = Double.toString(Math.random());
				msg.setJMSCorrelationID(correlationId);
		        producer.send(msg);  //Send Message       
		        logger.info("Message Send to Topic Successfully");																		// Session
		        logger.info("Coorelation Id:"+correlationId);		
		        if(readMessage){
			          Thread.sleep(5000);
			          Queue resp = session.createQueue(System.getProperty("ResponseQueue"));
				      QueueBrowser browser = session.createBrowser(resp);
				      Enumeration<Message> msgs = browser.getEnumeration();
				      if ( !msgs.hasMoreElements() ) { 
			        	logger.info("No messages in queue");
				      } else { 
			            while (msgs.hasMoreElements()) { 
			                Message tempMsg = (Message)msgs.nextElement(); 
			                
			                if(correlationId.equals(tempMsg.getJMSCorrelationID())){
			                	String messageText = ((TextMessage)tempMsg).getText();
			                	String responseFile = System.getProperty("ResponseFile");
			                	writeFile(messageText, responseFile);
			                	logger.info("Message retrieved and saved to "+responseFile); 
			                }
				          }
				      }
			        }
		        connection.close();
			
		} catch (Exception e) {
			logger.error(e.toString());
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.error(sw.toString());
			if(connection!=null){
				try{
					connection.close();
				}
				catch(Exception exp){
					
				}
				
			}
		}
    	logger.info("Completed");
	}
	
	private static void executeWebMethods(){
		Connection connection = null;
		try {
			PropertyConfigurator.configure("log4j.properties");
			// creating properties file for getting initial context
			Properties env = new Properties();
			env.setProperty("java.naming.factory.initial", System.getProperty("Initial"));
			env.setProperty("java.naming.provider.url", System.getProperty("URL"));
			
			env.setProperty("com.webmethods.jms.naming.clientgroup", System.getProperty("ClientGroup"));
			env.setProperty("java.naming.security.credentials", System.getProperty("Password"));
			env.setProperty("com.webmethods.jms.naming.keystore",
					System.getProperty("KeyStore"));
			//env.setProperty("com.webmethods.jms.naming.keystoretype", "PKCS12");
			env.setProperty("com.webmethods.jms.naming.truststore", System.getProperty("TrustStore"));
			//env.setProperty("com.webmethods.jms.ssl.truststoretype", "JKS");
			boolean readMessage = false;
			
			if("Y".equals(System.getProperty("readMessageFromResponse"))){
				readMessage = true;
			}
			Context jndiContext = null;
			// connect to JNDI using jndi.properties
			try {
				jndiContext = new InitialContext(env);
				logger.info("connected to JNDI provider " + jndiContext.toString());
			} catch (NamingException ex) {
				System.out.println("ERROR: failed to connect to JNDI provider");
				ex.printStackTrace();
				System.exit(0);
			}

			WmConnectionFactory conn = (WmConnectionFactory) jndiContext.lookup(System.getProperty("ConnectionFactory"));

			logger.info("Lookup Connection Factory Success " + conn.toString());
			String username = System.getProperty("UserName");
			String password = System.getProperty("Password");
			
			connection = conn.createConnection(username,password);// Create

			logger.info("Connection Created" + connection.toString());
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE); 
			Destination dest = (Destination) jndiContext.lookup(System.getProperty("RequestQueue"));  
			logger.info("Destination Created"+ dest);
			   
			MessageProducer producer = session.createProducer(dest);  //Create Message Producer       
			TextMessage msg = session.createTextMessage();  //Create Message
			String fileName = System.getProperty("FileName");
			String message = readFile(fileName,Charset.defaultCharset());
			msg.setText(message);
			msg.setStringProperty("siteid", System.getProperty("SiteId"));
			String correlationId = Double.toString(Math.random());
			msg.setJMSCorrelationID(correlationId);
	        producer.send(msg);  //Send Message       
	        logger.info("Message Send to Topic Successfully");																		// Session
	        logger.info("Coorelation Id:"+correlationId);
	        if(readMessage){
	          Thread.sleep(5000);
		      Queue resp = (Queue) jndiContext.lookup(System.getProperty("ResponseQueue"));
		      QueueBrowser browser = session.createBrowser(resp);
		      Enumeration<Message> msgs = browser.getEnumeration();
		      if ( !msgs.hasMoreElements() ) { 
	        	logger.info("No messages in queue");
		      } else { 
	            while (msgs.hasMoreElements()) { 
	                Message tempMsg = (Message)msgs.nextElement(); 
	                if(correlationId.equals(tempMsg.getJMSCorrelationID())){
	                	String responseFile = System.getProperty("ResponseFile");
	                	writeFile(tempMsg.toString(), responseFile);
	                	logger.info("Message retrieved and saved to "+responseFile); 
	                }
		          }
		      }
	        }
			       
			connection.close();
			
		} catch (Exception e) {
			logger.error(e.toString());
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			logger.error(sw.toString());
			if(connection!=null){
				try{
					connection.close();
				}
				catch(Exception exp){
					
				}
				
			}
		}
    	logger.info("Completed");
	}
	
	private  static String readFile(String path, Charset encoding) 
			  throws IOException 
	{
	  byte[] encoded = Files.readAllBytes(Paths.get(path));
	  return new String(encoded, encoding);
	}
	
	private static void writeFile(String inputText, String fileName) throws IOException {
		byte[] writeBytes = inputText.getBytes(); 
		OpenOption[] options = new OpenOption[] {  };
		Files.write(Paths.get(fileName), writeBytes,options);
		
	}

}
